//global variables
var centerX = 250;
var centerY = 250;
var xBoundMin = 100;
var xBoundMax = 500;
var yBoundMin = 50;
var yBoundMax = 400;
var xDirection = 1;
var yDirection = 1;
var speed = 5;
var toggleWord = "speedUp";


function setup() {
  createCanvas(800,450);
  frameRate(30);
}

function draw() {
	background(100);
	
	textSize(20);
	text("Speed = "+speed, 10,20);
	text("Toggle mode: "+toggleWord, 10,40);
	text("Press any key to change toggle mode.",10,60);
	text("A DVD screensaver is just linear back and forth motion",10,420);
	text("in the x and y direction simultaneously.",10,440);
	
	
	//Draw the icon for this frame, based on a center point.
	stroke(255);
	fill(255);
	ellipseMode(CENTER);
	text("DVD",centerX-21,centerY-10);
	noStroke();
	ellipse(centerX,centerY,50,10);
	fill(100);
	ellipse(centerX,centerY,15,5);
	fill(255);
	
	//draw first button (square)
	rectMode(CENTER);
	rect(600,100,50,50);
	fill(0);
	text("Go",585,107);
	
	//draw second button (circle)
	fill(255);
	ellipse(600,175,50,50);
	fill(0);
	text("TGL",580,182);

	fill(255);
	
	
	//Modify the centerpoint value so that it moves like a DVD screensaver.
	if((centerX<xBoundMin)||(centerX>xBoundMax))
	{
		xDirection*=-1;
	}
	if((centerY<yBoundMin)||(centerY>yBoundMax))
	{
		yDirection*=-1;
	}
	centerX +=(speed*xDirection);
	centerY +=(speed*yDirection);
}

function mousePressed(){
	if(mouseX>575 && mouseX<625 && mouseY>75 && mouseY<125){
		if(toggleWord == "speedUp")
		{
			speed++;
		}
		else if(toggleWord == "slowDown")
		{
			speed--;
		}
		else if(toggleWord == "flipVertical")
		{
			xDirection*=-1;
		}
		else if (toggleWord == "flipHorizontal")
		{
			yDirection*=-1;
		}
	}

	if(mouseX>575 && mouseX<625 && mouseY>150 && mouseY<200) {
		if(toggleWord == "speedUp")
		{
			toggleWord = "slowDown";
		}
		else if(toggleWord == "slowDown")
		{
			toggleWord = "flipVertical";
		}
		else if(toggleWord == "flipVertical")
		{
			toggleWord = "flipHorizontal";
		}
		else if (toggleWord == "flipHorizontal")
		{
			toggleWord = "speedUp";
		}
	}
}
