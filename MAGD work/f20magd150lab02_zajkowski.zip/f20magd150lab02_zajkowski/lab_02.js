function setup() {
  // put setup code here
  createCanvas(450,450);
  colorMode(HSB);
  background(268,90,35);
}

function draw() {
	colorMode(RGB);
	noStroke();
	fill(255,127,44);
    arc(225,225,225,225,0,2*PI);
	stroke(125,104,9);
	strokeWeight(26)
	bezier(120,185,0,300,450,315,335,200);
	noStroke();
	arc(225,225,225,225,PI,0);
	let c=color('#E8381C');
	fill(c);
	quad(133,160,335,200,335,225,113,210);
	fill(200);
   
}
