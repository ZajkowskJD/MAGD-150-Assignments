//global variables
var boxCenterX = 250;
var boxCenterY = 250;
var xBoundMin = 100;
var xBoundMax = 700;
var yBoundMin = 50;
var yBoundMax = 400;
var xDirection = 1;
var yDirection = 1;
var speed = 5;
var toggleWord = "speedUp";


function setup() {
  createCanvas(800,450);
  frameRate(30);
}

function draw() {
	background(100);
	
	textSize(20);
	text("Speed = "+speed, 10,20);
	text("Toggle mode: "+toggleWord, 10,40);
	text("Press any key to change toggle mode.",10,60);
	
	
	//Draw the box for this frame, based on a center point.
	stroke(0);
	fill(255);
	rectMode(CENTER);
	rect(boxCenterX,boxCenterY,50,10);
	quad(boxCenterX-25,boxCenterY-5,boxCenterX,boxCenterY-20,boxCenterX+50,boxCenterY-20,boxCenterX+25,boxCenterY-5);
	quad(boxCenterX+25,boxCenterY-5,boxCenterX+50,boxCenterY-20,boxCenterX+50,boxCenterY-10,boxCenterX+25,boxCenterY+5);
	noStroke();
	ellipseMode(CENTER);
	fill(255,160,51);
	ellipse(boxCenterX+15,boxCenterY-13,25,10);
	fill(255,251,145);
	ellipse(boxCenterX+15,boxCenterY-13,21,6);
	
	//Modify the centerpoint value so that it moves like a DVD screensaver.
	if((boxCenterX<xBoundMin)||(boxCenterX>xBoundMax))
	{
		xDirection*=-1;
	}
	if((boxCenterY<yBoundMin)||(boxCenterY>yBoundMax))
	{
		yDirection*=-1;
	}
	boxCenterX +=(speed*xDirection);
	boxCenterY +=(speed*yDirection);
}

function mousePressed(){
		if(toggleWord == "speedUp")
		{
			speed++;
		}
		else if(toggleWord == "slowDown")
		{
			speed--;
		}
		else if(toggleWord == "flipVertical")
		{
			xDirection*=-1;
		}
		else if (toggleWord == "flipHorizontal")
		{
			yDirection*=-1;
		}
		
}
function keyPressed(){
		if(toggleWord == "speedUp")
		{
			toggleWord = "slowDown";
		}
		else if(toggleWord == "slowDown")
		{
			toggleWord = "flipVertical";
		}
		else if(toggleWord == "flipVertical")
		{
			toggleWord = "flipHorizontal";
		}
		else if (toggleWord == "flipHorizontal")
		{
			toggleWord = "speedUp";
		}
}