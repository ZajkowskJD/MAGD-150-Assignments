let rollFilm = false;
let video;
let controls;
let reverb;

//the preload function is being used to preload the audio.
function preload() {
	soundFormats('mp3','ogg','wav');
	audio = loadSound('audio.mp3')
}

//the setup function is being used to apply aftereffects to the audio and
//setup the video playback and HTML button via p5.dom.
function setup() {
  // put setup code here
  createCanvas(900,50);
  audio.setVolume(0.75);
  reverb = new p5.Reverb();
  audio.disconnect();
  reverb.process(audio,150,70);
  video=createVideo(['video.mp4']);
  controls=createButton('play');
  controls.mousePressed(videoControls);
}

//the videoControls function is the internal logic gate for the audio and
//video elements of the program.
function videoControls() {
	if (rollFilm) {
		video.pause();
		audio.pause();
		controls.html('play');
	}
	else {
		video.play();
		audio.play();
		controls.html('pause');
	}
	rollFilm = !rollFilm;
}

//Prepare to meet God.
function draw() {

   textSize(48);
   text("Prepare to meet God.",0,40); 
}
