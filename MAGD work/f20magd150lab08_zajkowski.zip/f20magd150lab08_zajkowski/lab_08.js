
//This is a list of global variables, mainly used to store external files in P5.
var f1;
var f2;
var flipper=-1;
var lines = [];
var lineCount;
var pdf;
var imgs = [];

//Loads in the fonts, images and text file while setting the framerate to 9 to avoid excess jittering.
function setup() {
  createCanvas(500,400);
  pdf = createPDF();
  pdf.beginRecord();
  f1=loadFont("CaslonAntique.ttf");
  f2=loadFont("CaslonAntique-Italic.ttf");
  lines=loadStrings("lines.txt");
  lineCount=lines.length;
  imgs[0]=loadImage("background.jpg");
  imgs[1]=loadImage("logo.png");
  frameRate(9);
}

function draw() {
  background(123,126,209);
  stroke(100);
  fill(255);

  //Draws images with effects to the canvas.
  push();
  tint(163,249,255);
  imgs[0].resize(500,266);
  imgs[1].resize(259,259);
  image(imgs[0],0,0);
  noTint();
  image(imgs[1],120,200);
  pop();

  // Draws to text boxes with different fonts, animated to move slightly up and down.
  push();
  textFont(f1);
  textAlign(CENTER);
  textSize(24);
  text(lines[0], width/3, 30+(2*flipper));
  textFont(f2);
  textAlign (RIGHT);
  text(lines[1], width/2, 255+(-2*flipper));
  flipper*=-1;
  pop();
  
  
}

function mousePressed(){
	pdf.save();
}