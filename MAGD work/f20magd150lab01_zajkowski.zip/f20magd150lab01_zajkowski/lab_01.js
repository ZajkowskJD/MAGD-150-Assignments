function setup() {
  // put setup code here
  createCanvas(450,450);
  background(150);
}

function draw() {
	
	
	
	//building base (1 rect, 1 modified display mode)
	noStroke();
	rectMode(CORNERS);
	fill(240);
	rect(150,150,300,450);

	//roof bases (2 rectangles)
	fill(200);
	rect(125,100,325,175);
	rect(125,250,325,325);
	
	//roof shaping (2 ellipses, 2 2d shapes)
	fill(150);
	ellipse(125,100,200,140);
	ellipse(325,100,200,140);
	beginShape();
	vertex(125,250);
	vertex(225,250);
	vertex(125,325);
	vertex(125,250);
	endShape();
	beginShape();
	vertex(325,250);
	vertex(225,250);
	vertex(325,325);
	vertex(325,250);
	endShape();
	
	//fill gaps (2 2d shapes)
	fill(240);
	beginShape();
	vertex(225,250);
	vertex(150,250);
	vertex(150,306);
	vertex(225,250);
	endShape();
	beginShape();
	vertex(225,250);
	vertex(300,250);
	vertex(300,306);
	vertex(225,250);
	endShape();
	
	//sun (1 point)
	strokeWeight(60);
	stroke(240);
	point(50,50);
	
	//clock (1 point, 2 lines
	strokeWeight(30);
	point(225,150);
	stroke(50);
	strokeWeight(2);
	line(225,150,225,135);
	line(225,150,235,145);
	
	//window (1 rectangle,)
	rect(205,180,245,240);
}
