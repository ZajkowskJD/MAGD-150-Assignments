//This program stores 3 'tree' objects in an array, then displays them 
//graphically.

let trees;

//Note that the empty variable is initialized first and then assigned an 
//array of size 3. each slot in the array is given a TreeSprite object.

function setup() {
  createCanvas(400,400);
  trees = [3];
  trees[0] = new TreeSprite(200,300);
  trees[1] = new TreeSprite(100,300);
  trees[2] = new TreeSprite(300,300);
}

// This is mostly just boring background stuff, but each object has their 
// draw function called here.

function draw() {
background(18,42,120);
noStroke();
fill(217,235,255);
rectMode(CORNER);
rect(0,300,400,100);
trees[0].draw();
trees[1].draw();
trees[2].draw();
}


//Now THIS is where the good stuff is.
class TreeSprite {

//The purpose of this class's constructor is to give the center position
// of the tree by receiving an XY coordinate in the setup function and
// adding a randomized offset to the x-position.
  constructor(x,y){
	var centerX, centerY, offsetX;
	
	this.centerX = x;
	this.centerY = y;
	this.offsetX = random(15,-15);
  }
  
  //Using the center position and offset determined in the constructor, a
  //tree object is drawn at the given coordinate. Please not that the
  //centerpoint is the center of the trunk, not the whole tree.
  draw(){
    rectMode(CENTER);
	fill(120,66,19);
	rect(this.centerX+this.offsetX,this.centerY,20,40);
    fill(17,120,37);
    
    triangle(this.centerX+this.offsetX,
             this.centerY-60,
             this.centerX+this.offsetX+40,
             this.centerY-10,
             this.centerX+this.offsetX-40,
             this.centerY-10);
    
    triangle(this.centerX+this.offsetX,
             this.centerY-80,
             this.centerX+this.offsetX+40,
             this.centerY-30,
             this.centerX+this.offsetX-40,
             this.centerY-30);
    
    triangle(this.centerX+this.offsetX,
             this.centerY-100,
             this.centerX+this.offsetX+40,
             this.centerY-50,
             this.centerX+this.offsetX-40,
             this.centerY-50);
  }
}