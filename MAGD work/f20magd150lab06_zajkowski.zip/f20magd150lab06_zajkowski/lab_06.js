//Global variables used to determine the starting position for Pac-Man.
var centerX = 250;
var centerY = 250;

//This is a super duper basic canvas creation that I do with every project.
function setup() {
  createCanvas(800,450);
  frameRate(30);
}

//This draw function uses modular functions to create a still image of
//Pac-Man and his near identical twin that is totally canon.

//Mental note: I need to review push and pop in the future.
function draw() {
	background(100);
	
	fill(255);
	textSize(20);
	text("Original Copy",180,180);
	text("Scaled, rotated and translated",300,260);
	text("using custom functions",300,280);
	
	drawPacMan();
	push();
	  rotater();
	  translator();
	  scaler();
	  drawPacMan();
	pop();	
}


//All of my modular functions that I call all of one time. Hopefully you can
//believe me when I say I can use C++ a whole lot more effectively.

function translator() {
	translate(220,20);
}

function scaler() {
	scale(.9);
}

function rotater() {
	rotate(PI/15.0);
}

//Scratch that, this one gets called TWICE. p5.js savant over here. 
function drawPacMan() {
	//Draw the icon for this frame, based on a center point.
	stroke(255,247,0);
	fill(255,247,0);
	arc(centerX,centerY,100,100,PI/4,(7*PI)/4);
}
