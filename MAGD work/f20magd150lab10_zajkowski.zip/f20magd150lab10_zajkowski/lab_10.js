let newModel;
let jsonData;
let font;
let x;
let y;
let z;

function preload() {
	newModel=loadModel('Blender_Monkey_Suzanne.obj',true);
	jsonData = loadJSON('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson');
    font = loadFont('CaslonAntique.ttf');
}



function setup() {
  // put setup code here
  createCanvas(450,450,WEBGL);
  x = 0;
  y = 0;
  z = (height/2.0)/tan(PI*30.0/180.0);
}

function draw() {
	background(100);
	normalMaterial();
	ambientLight(255);
	pointLight(255,255,46,200,50,100);
    textFont(font, 24);
	
	text(jsonData.features[0].properties.place,0,0,0);
	
	push();
	translate(-100,0,0);
	box(70,70,70);
	pop();
	
	push();
	translate(0,-100,0);
	rotateX(frameCount*0.1);
    rotateY(frameCount*0.1);
    rotateZ(frameCount*0.1);
	cone(70,70,10,10,true);
	pop();
	
	push();
	translate(100,0,0);
	rotateX(PI/2);
	rotateZ(PI);
	model(newModel);
	pop();
	
	camera(x,y,z+sin(frameCount*0.05)*80,0,0,0,0,1,0);
}
