//create global variables
var divisor=10.0;
var incrementor=1.0;
var timer=0;

function setup() {
  // put setup code here
  createCanvas(450.0,450.0);
  constrain(divisor,5.0,15.0);
  frameRate(30);
}

function draw() {
	background(100);
	noStroke();
	fill(255);
	ellipse(225,225,width/divisor,height/divisor);
	stroke(0);
	strokeWeight(10);
	point(225,225);
	
	//calculate printed variables
	var mouseDist = dist(225,225,mouseX,mouseY);
	var xLerp = lerp(225,mouseX,.5);
	var yLerp = lerp(225,mouseY,.5);
	var lerpDist = dist(225,225,xLerp,yLerp);
	var radius = (width/divisor)/2.0;
	
	//changes radius every second
	if(timer%30==0)
	{
		divisor+=incrementor;
		if(divisor==5.0||divisor==15.0)
		{
			incrementor*=-1;
		}
	}
	
	//print variables every 5 seconds
	if(timer==150)
	{
	print("Mouse Position: "+mouseX+", "+mouseY);
	print("Distance from center: "+mouseDist);
	print("Half of Distance from center: "+lerpDist);
	print("Radius of Outer Circle: "+radius);
	print("\n\n\n");
	timer=0;
	}
	else
	{
		timer+=1;
	}
}
